Base templates for CI/CD Pipeline Project
